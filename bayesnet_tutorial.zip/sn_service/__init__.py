registry = {
    "bayes_service": {
        "grpc": 7003,
    },
}
from sn_service import common
